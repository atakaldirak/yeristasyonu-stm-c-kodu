﻿namespace LoraYerIstasyonu
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxConnection = new System.Windows.Forms.GroupBox();
            this.cmbPorts = new System.Windows.Forms.ComboBox();
            this.labelPort = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnRefreshPorts = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBoxSender = new System.Windows.Forms.GroupBox();
            this.labelCommand = new System.Windows.Forms.Label();
            this.txtCommand = new System.Windows.Forms.TextBox();
            this.btnSendCommand = new System.Windows.Forms.Button();
            this.groupBoxReceiver = new System.Windows.Forms.GroupBox();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.groupBoxConnection.SuspendLayout();
            this.groupBoxSender.SuspendLayout();
            this.groupBoxReceiver.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxConnection
            // 
            this.groupBoxConnection.Controls.Add(this.lblStatus);
            this.groupBoxConnection.Controls.Add(this.btnRefreshPorts);
            this.groupBoxConnection.Controls.Add(this.btnConnect);
            this.groupBoxConnection.Controls.Add(this.cmbPorts);
            this.groupBoxConnection.Controls.Add(this.labelPort);
            this.groupBoxConnection.Location = new System.Drawing.Point(85, 96);
            this.groupBoxConnection.Name = "groupBoxConnection";
            this.groupBoxConnection.Size = new System.Drawing.Size(200, 125);
            this.groupBoxConnection.TabIndex = 0;
            this.groupBoxConnection.TabStop = false;
            this.groupBoxConnection.Text = "Bağlantı Ayarları";
            // 
            // cmbPorts
            // 
            this.cmbPorts.FormattingEnabled = true;
            this.cmbPorts.Location = new System.Drawing.Point(68, 24);
            this.cmbPorts.Name = "cmbPorts";
            this.cmbPorts.Size = new System.Drawing.Size(121, 21);
            this.cmbPorts.TabIndex = 2;
            // 
            // labelPort
            // 
            this.labelPort.AutoSize = true;
            this.labelPort.Location = new System.Drawing.Point(6, 27);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new System.Drawing.Size(56, 13);
            this.labelPort.TabIndex = 1;
            this.labelPort.Text = "COM Port:";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(68, 52);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(121, 23);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "BAĞLAN";
            this.btnConnect.UseVisualStyleBackColor = true;
            // 
            // btnRefreshPorts
            // 
            this.btnRefreshPorts.Location = new System.Drawing.Point(68, 81);
            this.btnRefreshPorts.Name = "btnRefreshPorts";
            this.btnRefreshPorts.Size = new System.Drawing.Size(121, 23);
            this.btnRefreshPorts.TabIndex = 4;
            this.btnRefreshPorts.Text = "YENİLE";
            this.btnRefreshPorts.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(7, 106);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(38, 13);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Durum";
            // 
            // groupBoxSender
            // 
            this.groupBoxSender.Controls.Add(this.btnSendCommand);
            this.groupBoxSender.Controls.Add(this.txtCommand);
            this.groupBoxSender.Controls.Add(this.labelCommand);
            this.groupBoxSender.Location = new System.Drawing.Point(291, 96);
            this.groupBoxSender.Name = "groupBoxSender";
            this.groupBoxSender.Size = new System.Drawing.Size(200, 125);
            this.groupBoxSender.TabIndex = 1;
            this.groupBoxSender.TabStop = false;
            this.groupBoxSender.Text = "Komut Gönderici";
            // 
            // labelCommand
            // 
            this.labelCommand.AutoSize = true;
            this.labelCommand.Location = new System.Drawing.Point(0, 30);
            this.labelCommand.Name = "labelCommand";
            this.labelCommand.Size = new System.Drawing.Size(98, 13);
            this.labelCommand.TabIndex = 0;
            this.labelCommand.Text = "Komut (4 Karakter):";
            // 
            // txtCommand
            // 
            this.txtCommand.Location = new System.Drawing.Point(99, 27);
            this.txtCommand.MaxLength = 4;
            this.txtCommand.Name = "txtCommand";
            this.txtCommand.Size = new System.Drawing.Size(95, 20);
            this.txtCommand.TabIndex = 1;
            // 
            // btnSendCommand
            // 
            this.btnSendCommand.Location = new System.Drawing.Point(99, 54);
            this.btnSendCommand.Name = "btnSendCommand";
            this.btnSendCommand.Size = new System.Drawing.Size(95, 23);
            this.btnSendCommand.TabIndex = 2;
            this.btnSendCommand.Text = "GÖNDER";
            this.btnSendCommand.UseVisualStyleBackColor = true;
            // 
            // groupBoxReceiver
            // 
            this.groupBoxReceiver.Controls.Add(this.txtLog);
            this.groupBoxReceiver.Location = new System.Drawing.Point(497, 96);
            this.groupBoxReceiver.Name = "groupBoxReceiver";
            this.groupBoxReceiver.Size = new System.Drawing.Size(207, 125);
            this.groupBoxReceiver.TabIndex = 2;
            this.groupBoxReceiver.TabStop = false;
            this.groupBoxReceiver.Text = "Alınan Veri Logu";
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(6, 23);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(195, 92);
            this.txtLog.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBoxReceiver);
            this.Controls.Add(this.groupBoxSender);
            this.Controls.Add(this.groupBoxConnection);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxConnection.ResumeLayout(false);
            this.groupBoxConnection.PerformLayout();
            this.groupBoxSender.ResumeLayout(false);
            this.groupBoxSender.PerformLayout();
            this.groupBoxReceiver.ResumeLayout(false);
            this.groupBoxReceiver.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxConnection;
        private System.Windows.Forms.Label labelPort;
        private System.Windows.Forms.ComboBox cmbPorts;
        private System.Windows.Forms.Button btnRefreshPorts;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox groupBoxSender;
        private System.Windows.Forms.Label labelCommand;
        private System.Windows.Forms.TextBox txtCommand;
        private System.Windows.Forms.Button btnSendCommand;
        private System.Windows.Forms.GroupBox groupBoxReceiver;
        private System.Windows.Forms.TextBox txtLog;
    }
}


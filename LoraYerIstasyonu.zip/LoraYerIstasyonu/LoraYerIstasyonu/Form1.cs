﻿using System;
using System.Drawing;
using System.IO.Ports;
using System.Management; // WMI İÇİN EKLENDİ
using System.Text;
using System.Windows.Forms;

namespace LoraYerIstasyonu
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort = new SerialPort();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshComPorts();
            UpdateConnectionStatus(false);
        }

        // DÜZELTİLMİŞ METOD - WMI KULLANARAK PORTLARI LİSTELER
        private void RefreshComPorts()
        {
            cmbPorts.Items.Clear();

            try
            {
                // WMI kullanarak, isminde "(COM" geçen tüm donanımları sorgula.
                // Bu, "STMicroelectronics Virtual COM Port (COM3)" gibi aygıtları bulur.
                ManagementObjectSearcher searcher =
                    new ManagementObjectSearcher("root\\CIMV2",
                    "SELECT * FROM Win32_PnPEntity WHERE Caption LIKE '%(COM%'");

                foreach (ManagementObject queryObj in searcher.Get())
                {
                    // Cihazın adını al, örn: "STMicroelectronics Virtual COM Port (COM3)"
                    string deviceName = queryObj["Caption"].ToString();

                    // Cihaz adının içinden sadece "COMx" kısmını ayıkla
                    int startIndex = deviceName.LastIndexOf("(COM");
                    if (startIndex >= 0)
                    {
                        int endIndex = deviceName.IndexOf(")", startIndex);
                        if (endIndex > startIndex)
                        {
                            string portName = deviceName.Substring(startIndex + 1, endIndex - startIndex - 1);
                            cmbPorts.Items.Add(portName);
                        }
                    }
                }
            }
            catch (ManagementException ex)
            {
                MessageBox.Show($"Donanım portları sorgulanırken bir WMI hatası oluştu: {ex.Message}");
            }

            // Port bulunduysa ilkini seç
            if (cmbPorts.Items.Count > 0)
            {
                cmbPorts.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Sistemde herhangi bir COM portu bulunamadı. Lütfen kartın bağlı olduğundan ve sürücüsünün Aygıt Yöneticisi'nde göründüğünden emin olun.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefreshPorts_Click(object sender, EventArgs e)
        {
            RefreshComPorts();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                try
                {
                    serialPort.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Port kapatılırken hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                UpdateConnectionStatus(false);
            }
            else
            {
                if (cmbPorts.SelectedItem == null)
                {
                    MessageBox.Show("Lütfen bir COM portu seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    serialPort.PortName = cmbPorts.SelectedItem.ToString();
                    serialPort.BaudRate = 9600;
                    serialPort.Parity = Parity.None;
                    serialPort.DataBits = 8;
                    serialPort.StopBits = StopBits.One;
                    serialPort.DataReceived += SerialPort_DataReceived;
                    serialPort.Open();
                    UpdateConnectionStatus(true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Bağlantı hatası: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    UpdateConnectionStatus(false);
                }
            }
        }

        private void btnSendCommand_Click(object sender, EventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                MessageBox.Show("Komut göndermek için önce bağlantı kurmalısınız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (txtCommand.Text.Length != 4)
            {
                MessageBox.Show("Lütfen tam olarak 4 karakterlik bir komut girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                byte[] buffer = Encoding.ASCII.GetBytes(txtCommand.Text);
                serialPort.Write(buffer, 0, buffer.Length);
                LogData($"[TX] >> {txtCommand.Text}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Veri gönderilirken hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int bytesToRead = serialPort.BytesToRead;
            if (bytesToRead == 0) return;

            byte[] buffer = new byte[bytesToRead];

            try
            {
                serialPort.Read(buffer, 0, bytesToRead);
                string hexData = BitConverter.ToString(buffer).Replace("-", " ");
                this.Invoke(new Action(() => LogData($"[RX] << {hexData}")));
            }
            catch (Exception ex)
            {
                this.Invoke(new Action(() =>
                   MessageBox.Show($"Veri alınırken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ));
            }
        }

        private void LogData(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action(() => LogData(message)));
                return;
            }
            txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
        }

        private void UpdateConnectionStatus(bool isConnected)
        {
            if (isConnected)
            {
                lblStatus.Text = $"Durum: Bağlı ({serialPort.PortName})";
                lblStatus.ForeColor = Color.Green;
                btnConnect.Text = "BAĞLANTIYI KES";
                cmbPorts.Enabled = false;
                btnRefreshPorts.Enabled = false;
                groupBoxSender.Enabled = true;
            }
            else
            {
                lblStatus.Text = "Durum: Bağlı Değil";
                lblStatus.ForeColor = Color.Red;
                btnConnect.Text = "BAĞLAN";
                cmbPorts.Enabled = true;
                btnRefreshPorts.Enabled = true;
                groupBoxSender.Enabled = false;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }
    }
}